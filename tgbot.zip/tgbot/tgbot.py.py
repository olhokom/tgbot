import os.path
import pickle
import time

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.errors import HttpError
from googleapiclient.discovery import build
from telegram import Bot
from telegram.error import TelegramError


# Google Drive API kimlik doğrulama bilgileri
SCOPES = ['https://www.googleapis.com/auth/drive.metadata.readonly']
TOKEN_PICKLE_FILE = 'token.pickle'
CREDENTIALS_FILE = 'credentials.json'
DRIVE_FILE_ID = 'YOUR_GOOGLE_DRIVE_FILE_ID'

# Telegram bot API kimlik doğrulama bilgileri
TELEGRAM_BOT_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN'
TELEGRAM_CHAT_ID = 'YOUR_TELEGRAM_CHAT_ID'


def get_gdrive_service():
    """Google Drive API hizmetini döndürür."""
    creds = None
    # Kaydedilmiş kimlik doğrulama bilgilerini yükle
    if os.path.exists(TOKEN_PICKLE_FILE):
        with open(TOKEN_PICKLE_FILE, 'rb') as token:
            creds = pickle.load(token)
    # Kaydedilmiş kimlik doğrulama bilgileri geçerli değilse kullanıcıya kimlik doğrulama isteği göster
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        # Kimlik doğrulama bilgilerini kaydet
        with open(TOKEN_PICKLE_FILE, 'wb') as token:
            pickle.dump(creds, token)
    # API hizmetini döndür
    service = build('drive', 'v3', credentials=creds)
    return service


def send_telegram_message(message):
    """Telegram botuna bildirim mesajı gönderir."""
    try:
        bot = Bot(token=TELEGRAM_BOT_TOKEN)
        bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message)
    except TelegramError as e:
        print('Bildirim mesajı gönderilemedi: ' + str(e))


def main():
    """Google Drive dosyasının erişim durumunu kontrol eder ve Telegram botuna bildirim gönderir."""
    service = get_gdrive_service()
    try:
        # Google Drive dosyasının erişim durumunu kontrol et
        file = service.files().get(fileId=DRIVE_FILE_ID, fields='trashed').execute()
        if file.get('trashed', False):
            # Dosya çöp kutusuna taşınmışsa, Telegram botuna bildirim gönder
            send_telegram_message('Google Drive dosyasına erişim kaybedildi!')
    except HttpError as error:
        print(f'Hata: {error}')
        send_telegram_message('Google Drive dosyasına erişim kaybedildi! Hata: ' + str(error))
    

if __name__ == '__main__':
    # Betiği belirli aralıklarla çalıştırmak için bir zamanlayıcı kullanabilirsiniz
    # Ö
